﻿## Disclaimer
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR
# PARTICULAR PURPOSE. 
#
# CODE IS WRITTEN FOR DEMO PURPOSES 
# (C) Martin Guth and others, 2020

Import-Module dbatools;
$workingdir = "C:\SQL\workloadtests\Demo";
Set-Location $workingdir;

# Save SQL Authentication for the script to avoid prompts (CAUTION...insecure...only used for demo purpose)
$password = ConvertTo-SecureString 'P4$$w0rd!' -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential ('sa', $password)

# Save start time and generate a marked transaction
Get-Date -Format HH:mm:ss.fff > "$(Get-Date -Format yyyyMMdd_HHMM)_record.start";
$sql = "BEGIN TRANSACTION CaptureStart
   WITH MARK 'CaptureStart';
SELECT GETDATE();
COMMIT TRANSACTION CaptureStart;";
Invoke-Dbaquery -SqlInstance localhost -SqlCredential $credential -Database StackOverflow2010 -Query $sql;

# drop an existing SQLite Database to avoid appending to an existing file
If (Test-Path("$workingdir\StackOverflow.sqlite"))
{
    Remove-Item $workingdir\StackOverflow.sqlite;
}
# start the workload
& "C:\Program Files\WorkloadTools\SqlWorkload.exe" --file "$workingdir\capture.json" --Log "$workingdir\capture_$(Get-Date -Format "yyyyMMdd_HHmmss").log"